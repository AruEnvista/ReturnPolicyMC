package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;
import java.math.BigDecimal;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@Document("returnpolicydb")
public class SalesOrderLines {

    @NonNull
    private BigDecimal ordered_quantity;

    @NonNull
    private String department_code;

    @NonNull
    private String status;

    @NonNull
    private BigDecimal statusQty;

    @NonNull
    private String delivery_type;

    private String delivery_date;

    @NonNull
    private String prime_line_number;

    private String sub_line_number;

    private String item_type;

    @NonNull
    private BigDecimal returnable_quantity;

    private boolean is_returnable;

    private boolean return_window_period;

    private boolean within_returnWindow;

    private BigDecimal return_window_timePeriod;

    private List<LineCharge> line_charges;

    private List<LineTax> line_taxes;

    private List<LinePriceInformation> line_price_information;

    private ItemDetails item_details;

    private List<OrderStatus> order_statuses;

}
