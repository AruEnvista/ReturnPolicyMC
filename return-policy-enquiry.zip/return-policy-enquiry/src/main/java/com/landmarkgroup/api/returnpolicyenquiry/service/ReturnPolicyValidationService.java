package com.landmarkgroup.api.returnpolicyenquiry.service;

import com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel.ExternalOrderRequest;
import com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel.*;
import com.landmarkgroup.api.returnpolicyenquiry.mapper.BusinessMapper;
import com.landmarkgroup.api.returnpolicyenquiry.repository.SalesOrderRepository;
import org.drools.core.event.DefaultAgendaEventListener;
import org.kie.api.event.rule.AfterMatchFiredEvent;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;
import org.reactivestreams.Publisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import java.util.Arrays;

@Service
public class ReturnPolicyValidationService {

    private BusinessMapper mapper;
    private KieContainer kieContainer;
    private SalesOrderRepository repo;

    ReturnPolicyValidationService(BusinessMapper mapper, KieContainer kieContainer,
                                  SalesOrderRepository repo) {
        this.mapper = mapper;
        this.kieContainer = kieContainer;
        this.repo = repo;
    }
    private String sessionName = "returnPolicySession";

    public Publisher<ResponseEntity<ExternalOrderRequest>> validateOrderForReturns(String orderNumber,ExternalOrderRequest orderRequest) {
        //SalesOrderRequest requestToOms = mapper.mapFromExternalOrderToOMSOrder(orderRequest,orderNumber);

        SalesOrderResponse order1 = new SalesOrderResponse();
        order1.setOrder_date ( "2019-11-21T14:28:33+04:00" );
        order1.setOrderNumber ( "0090043" );
        order1.setEnterprise_code ( "Kuwait" );
        order1.setSource ( "RTS" );
        SalesOrderLines s= new SalesOrderLines (  );
        s.setDepartment_code ( "29");
        s.setReturnable_quantity (java.math.BigDecimal.valueOf ( 4 ));
        s.setPrime_line_number ( "1" );
        ItemDetails i1= new ItemDetails (  );
        i1.setItem_identifier ( "ABC" );
        s.setItem_details ( i1 );
        s.setDelivery_type ( "HC" );
        SalesOrderLines s1= new SalesOrderLines (  );
        s1.setDepartment_code ( "02");
        s1.setReturnable_quantity (java.math.BigDecimal.valueOf ( 5 ));
        s1.setPrime_line_number ( "2" );
        ItemDetails i2= new ItemDetails (  );
        i2.setItem_identifier ( "ABC" );
        s1.setItem_details ( i2);
        s1.setDelivery_type ( "CC" );
        order1.setOrder_lines ( Arrays.asList (s,s1));

        //repo.insert(order1).subscribe ();
        //order1.setStatusList(Arrays.asList("art","iooo"));


        StatelessKieSession kieSession = kieContainer.newStatelessKieSession(sessionName);

        Mono<SalesOrderResponse> salesOrderResponsePostApplyingRules = repo.findByOrderNumber(orderRequest.getCustomer_order_id())
                .flatMap(existingProduct -> {
                    kieSession.addEventListener(new DefaultAgendaEventListener () {
                        //this event will be executed after the rule matches with the model data
                        public void afterMatchFired(AfterMatchFiredEvent event) {
                            super.afterMatchFired(event);
                            System.out.println("data1"+event.getMatch().getRule().getName());//prints the rule name that fires the event
                        }
                    });
                    kieSession.execute(mapper.validateSalesOrder(existingProduct,orderRequest));
                    System.out.println ( "After rules"+ existingProduct);
                    return Mono.just(existingProduct).log("Log the outPut message111:-"+existingProduct);
                } );
               /* .switchIfEmpty ( orderDAO.findByOrderNo ( orderNumber ).flatMap ( existingProduct -> {
            kieSession.insert ( existingProduct );
            kieSession.fireAllRules ();
            kieSession.dispose ();
            return Mono.just ( existingProduct );
        } ).map ( o3 -> ResponseEntity.ok ( o3 ) )
                .defaultIfEmpty ( ResponseEntity.notFound ().build () ) ).log ();*/


      /* SalesOrderResponsePostApplyingRules.flatMap ( nextObject-> {
            if(nextObject.isRTS ()){
                //prepare doc(use same requestToOms object)
                //call return API

                ParallelFlux<OmsReturnOrder> returnResponsePostApplyingRules = returnRepo.findByReturnOrderNumber ( orderRequest.getCustomer_order_id () )
                        .parallel (3).runOn( Schedulers.elastic())
                        .flatMap ( returnOrders -> {
                            mapper.ValidateReturnOrder ( returnOrders, nextObject);
                            System.out.println ( "After rules for returnOrder" + returnOrders );
                            return Flux.just ( returnOrders ).log ( "Log the outPut message of return:-" + returnOrders );
                        } );
            }
            return SalesOrderResponsePostApplyingRules;
        });*/

        /*return ExternalSystemOrderResponse*/
        Mono<ExternalOrderRequest> externalOrderResponse = mapper.mapFromOMSOrderToExternalOrder(salesOrderResponsePostApplyingRules, orderRequest);

        return externalOrderResponse.map ( o1 -> ResponseEntity.status ( HttpStatus.OK ).body ( o1 ) )
                .defaultIfEmpty ( ResponseEntity.notFound ().build () );
    }
}
