package com.landmarkgroup.api.returnpolicyenquiry.mapper;

import com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel.ExternalOrderRequest;
import com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel.SalesOrderRequest;
import com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel.SalesOrderResponse;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Component
public class BusinessMapper {

    public SalesOrderRequest mapFromExternalOrderToOMSOrder(ExternalOrderRequest orderRequest,String orderNumber) {
        SalesOrderRequest salesOrder = new SalesOrderRequest ();
        salesOrder.setEnterprise_code ( orderRequest.getEnterprise_code () );
        salesOrder.setCustomer_order_number ( orderNumber );
        salesOrder.setDocument_type ( BigDecimal.valueOf ( 000001 ) );
        return salesOrder;
    }

    public Mono<ExternalOrderRequest> mapFromOMSOrderToExternalOrder(Mono<SalesOrderResponse> omsSalesOrderResponse,
                                                                     ExternalOrderRequest externalOrderRequest) {

        return omsSalesOrderResponse.flatMap ( existingProduct -> {
            externalOrderRequest.setCustomer_order_id ( existingProduct.getOrderNumber () );
            externalOrderRequest.setEnterprise_code ( existingProduct.getEnterprise_code () );
            externalOrderRequest.set_legacy_order ( existingProduct.getIsLegacyOrder () );
            externalOrderRequest.setStatus ( "SUCCESS" );//TODO: clarification required: on what basis is the value to be set? and what are the possible values?
            externalOrderRequest.getOrder_lines ().stream ().forEach ( line1 -> {
                existingProduct.getOrder_lines ().stream ().forEach ( line2 -> {
                    if (line1.getItem_id ().equals ( line2.getItem_details ().getItem_identifier () )) {
                        line1.setItem_description ( line2.getItem_details ().getItem_identifier () );
                        line1.setMaximum_returnable_quantity ( line2.getReturnable_quantity () );
                        line1.set_returnable ( line2.is_returnable () );
                        line1.setWith_in_return_window ( line2.isReturn_window_period () );
                        line1.setReturn_window_period ( line2.getReturn_window_timePeriod () );
                        line1.setOrdered_quantity ( line2.getReturnable_quantity () );
                        line1.setDepartment_code ( line2.getDepartment_code () );
                        line1.setDelivery_type ( line2.getDelivery_type () );
                    }
                } );
            } );
            System.out.println ( "values are"+ externalOrderRequest);
            return Mono.just ( externalOrderRequest ).log ();
        } );
    }


    public SalesOrderResponse validateSalesOrder(SalesOrderResponse omsSalesOrderResponse,
                                                 ExternalOrderRequest externalOrderRequest) {

        if (!omsSalesOrderResponse.getOrder_lines ().isEmpty ()) {
            List<String> externalItemList = new ArrayList<> ();
            externalOrderRequest.getOrder_lines ().stream ().forEach ( line3 -> {
                externalItemList.add ( line3.getItem_id () );
            } );

            omsSalesOrderResponse.getOrder_lines ().stream ().forEach ( line2 -> {
                if (!externalItemList.contains ( line2.getItem_details ().getItem_identifier () )) {
                    omsSalesOrderResponse.getOrder_lines ().remove ( line2 );
                }
            } );

        }
        return omsSalesOrderResponse;
    }

    //TODO
    /*public SalesOrderResponse validateReturnOrder(OmsReturnOrder omsReturnOrder,
                                                  SalesOrderResponse omsSalesOrderResponse) {
        BigDecimal sumValue = new BigDecimal ( 0.0 );
        omsReturnOrder.stream ().forEach ( returnOrder -> {
            omsSalesOrderResponse.getOrder_lines ().stream ().forEach ( line1 -> {
                returnOrder.getOrder_lines ().stream ().forEach ( line2 -> {
                    if (line1.getItem_details ().getItem_identifier ().equals ( line2.getItem_identifier () )) {
                        sumValue.add ( line2.getReturn_quantity () );
                    }
                } );
            } );
        } );

        return omsSalesOrderResponse;
    }*/
}
