package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class PaymentMethod {

    private String payment_type;

    private BigDecimal amount;

    private String payment_reference3;

    private String payment_reference4;


}

