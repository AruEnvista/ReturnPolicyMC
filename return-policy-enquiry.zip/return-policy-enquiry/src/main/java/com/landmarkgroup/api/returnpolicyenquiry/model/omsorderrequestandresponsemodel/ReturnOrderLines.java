package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@Document("returnpolicydb")
public class ReturnOrderLines {
    @NonNull
    private String item_identifier;

    @NonNull
    private String line_status;

    @NonNull
    private BigDecimal return_quantity;

}
