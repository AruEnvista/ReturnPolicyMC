package com.landmarkgroup.api.returnpolicyenquiry;

import org.kie.api.KieServices;
import org.kie.api.cdi.KContainer;
import org.kie.api.cdi.KReleaseId;
import org.kie.api.runtime.KieContainer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ReturnPolicyEnquiryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReturnPolicyEnquiryApplication.class, args);
	}

	@Bean
	@KContainer
	@KReleaseId(groupId = "com.landmarkgroup.api",artifactId = "return-policy-enquiry-rules", version = "0.0.1-SNAPSHOT")
	public KieContainer kieContainer() {
		return KieServices.Factory.get().getKieClasspathContainer();
	}



}
