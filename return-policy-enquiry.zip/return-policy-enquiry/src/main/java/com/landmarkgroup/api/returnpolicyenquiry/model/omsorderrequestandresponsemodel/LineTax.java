package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class LineTax {
    @NonNull
    private String charge_category;

    @NonNull
    private String charge_name;

    @NonNull
    private String tax;

    @NonNull
    private String tax_name;

    @NonNull
    private String taxable_percentage;
}
